/* eslint-disable import/no-unresolved */
import React from 'react'

import './styles.module.scss'

const Contact = () => {
  return (
    <div className="contact">
      
    </div>
  )
}

export default Contact
